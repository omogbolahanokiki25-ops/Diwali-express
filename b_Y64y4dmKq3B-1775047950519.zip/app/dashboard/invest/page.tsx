import { createClient } from '@/lib/supabase/server'
import { InvestmentPlans } from '@/components/dashboard/investment-plans'
import { ActiveInvestment } from '@/components/dashboard/active-investment'

export default async function InvestPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  const [{ data: plans }, { data: activeInvestment }] = await Promise.all([
    supabase
      .from('investment_plans')
      .select('*')
      .eq('is_active', true)
      .order('amount', { ascending: true }),
    supabase
      .from('user_investments')
      .select('*, plan:investment_plans(*)')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single(),
  ])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Investment Plans</h1>
        <p className="text-muted-foreground">
          Choose a plan to start earning daily rewards
        </p>
      </div>

      {activeInvestment && <ActiveInvestment investment={activeInvestment} />}

      <InvestmentPlans plans={plans || []} userId={user.id} hasActiveInvestment={!!activeInvestment} />
    </div>
  )
}
