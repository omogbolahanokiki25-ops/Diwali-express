import { createClient } from '@/lib/supabase/server'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Trophy, TrendingUp, Users, Medal } from 'lucide-react'

export default async function LeaderboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  // Get top earners
  const { data: topEarners } = await supabase
    .from('wallets')
    .select('user_id, total_earnings, profiles(full_name)')
    .order('total_earnings', { ascending: false })
    .limit(20)

  // Get top referrers
  const { data: topReferrers } = await supabase
    .from('profiles')
    .select('id, full_name, referral_count')
    .order('referral_count', { ascending: false })
    .limit(20)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <div className="w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center">
            <Trophy className="w-4 h-4 text-white" />
          </div>
        )
      case 2:
        return (
          <div className="w-8 h-8 rounded-full bg-gray-400 flex items-center justify-center">
            <Medal className="w-4 h-4 text-white" />
          </div>
        )
      case 3:
        return (
          <div className="w-8 h-8 rounded-full bg-amber-600 flex items-center justify-center">
            <Medal className="w-4 h-4 text-white" />
          </div>
        )
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
            <span className="text-sm font-medium">{rank}</span>
          </div>
        )
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Leaderboard</h1>
        <p className="text-muted-foreground">
          See top earners and referrers
        </p>
      </div>

      <Tabs defaultValue="earners" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="earners" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Top Earners
          </TabsTrigger>
          <TabsTrigger value="referrers" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Top Referrers
          </TabsTrigger>
        </TabsList>

        <TabsContent value="earners" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Top Earners
              </CardTitle>
            </CardHeader>
            <CardContent>
              {topEarners && topEarners.length > 0 ? (
                <div className="space-y-3">
                  {topEarners.map((entry, index) => (
                    <div
                      key={entry.user_id}
                      className={`flex items-center justify-between p-3 rounded-lg ${
                        entry.user_id === user.id ? 'bg-primary/10 border border-primary/20' : 'bg-muted/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {getRankBadge(index + 1)}
                        <div>
                          <p className="font-medium">
                            {(entry.profiles as { full_name: string | null })?.full_name || 'Anonymous'}
                            {entry.user_id === user.id && (
                              <span className="text-xs text-primary ml-2">(You)</span>
                            )}
                          </p>
                        </div>
                      </div>
                      <span className="font-bold text-green-600">
                        {formatCurrency(entry.total_earnings)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No data available yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrers" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Top Referrers
              </CardTitle>
            </CardHeader>
            <CardContent>
              {topReferrers && topReferrers.length > 0 ? (
                <div className="space-y-3">
                  {topReferrers.map((entry, index) => (
                    <div
                      key={entry.id}
                      className={`flex items-center justify-between p-3 rounded-lg ${
                        entry.id === user.id ? 'bg-primary/10 border border-primary/20' : 'bg-muted/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {getRankBadge(index + 1)}
                        <div>
                          <p className="font-medium">
                            {entry.full_name || 'Anonymous'}
                            {entry.id === user.id && (
                              <span className="text-xs text-primary ml-2">(You)</span>
                            )}
                          </p>
                        </div>
                      </div>
                      <span className="font-bold">
                        {entry.referral_count} referrals
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No data available yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
