import { createClient } from '@/lib/supabase/server'
import { WalletOverview } from '@/components/dashboard/wallet-overview'
import { WithdrawalForm } from '@/components/dashboard/withdrawal-form'
import { WithdrawalHistory } from '@/components/dashboard/withdrawal-history'
import { TransactionHistory } from '@/components/dashboard/transaction-history'

export default async function WalletPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  const [
    { data: profile },
    { data: wallet },
    { data: withdrawals },
    { data: transactions }
  ] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', user.id).single(),
    supabase.from('wallets').select('*').eq('user_id', user.id).single(),
    supabase
      .from('withdrawals')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10),
    supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20),
  ])

  const canWithdraw = (wallet?.balance || 0) >= 5000 && (profile?.referral_count || 0) >= 3

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Wallet</h1>
        <p className="text-muted-foreground">
          Manage your earnings and withdrawals
        </p>
      </div>

      {/* Wallet Overview */}
      <WalletOverview wallet={wallet} />

      {/* Withdrawal Form */}
      <WithdrawalForm
        userId={user.id}
        balance={wallet?.balance || 0}
        referralCount={profile?.referral_count || 0}
        canWithdraw={canWithdraw}
      />

      {/* Withdrawal History */}
      <WithdrawalHistory withdrawals={withdrawals || []} />

      {/* Transaction History */}
      <TransactionHistory transactions={transactions || []} />
    </div>
  )
}
