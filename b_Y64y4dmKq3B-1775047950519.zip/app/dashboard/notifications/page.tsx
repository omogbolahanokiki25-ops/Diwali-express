import { createClient } from '@/lib/supabase/server'
import { NotificationList } from '@/components/dashboard/notification-list'

export default async function NotificationsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  const { data: notifications } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(50)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Notifications</h1>
        <p className="text-muted-foreground">
          Stay updated with your account activity
        </p>
      </div>

      <NotificationList notifications={notifications || []} userId={user.id} />
    </div>
  )
}
