import { createClient } from '@/lib/supabase/server'
import { DashboardStats } from '@/components/dashboard/dashboard-stats'
import { QuickActions } from '@/components/dashboard/quick-actions'
import { DailyProgress } from '@/components/dashboard/daily-progress'
import { RecentActivity } from '@/components/dashboard/recent-activity'
import { DailyBonusCard } from '@/components/dashboard/daily-bonus-card'

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  // Fetch all dashboard data in parallel
  const [
    { data: profile },
    { data: wallet },
    { data: activeInvestment },
    { data: todayPlays },
    { data: recentTransactions },
    { data: todayBonus }
  ] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', user.id).single(),
    supabase.from('wallets').select('*').eq('user_id', user.id).single(),
    supabase
      .from('user_investments')
      .select('*, plan:investment_plans(*)')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single(),
    supabase
      .from('song_plays')
      .select('*')
      .eq('user_id', user.id)
      .eq('play_date', new Date().toISOString().split('T')[0]),
    supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(5),
    supabase
      .from('daily_bonuses')
      .select('*')
      .eq('user_id', user.id)
      .eq('bonus_date', new Date().toISOString().split('T')[0])
      .single()
  ])

  const maxDailyPlays = activeInvestment?.plan?.daily_songs || 0
  const currentPlays = todayPlays?.length || 0

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div>
        <h1 className="text-2xl font-bold">
          Welcome back, {profile?.full_name?.split(' ')[0] || 'User'}!
        </h1>
        <p className="text-muted-foreground">
          {"Here's what's happening with your account today."}
        </p>
      </div>

      {/* Daily Bonus */}
      <DailyBonusCard 
        userId={user.id} 
        hasClaimed={!!todayBonus} 
        hasActiveInvestment={!!activeInvestment}
      />

      {/* Stats Cards */}
      <DashboardStats
        wallet={wallet}
        activeInvestment={activeInvestment}
        currentPlays={currentPlays}
        maxDailyPlays={maxDailyPlays}
        referralCount={profile?.referral_count || 0}
      />

      {/* Quick Actions */}
      <QuickActions hasActiveInvestment={!!activeInvestment} />

      {/* Daily Progress */}
      {activeInvestment && (
        <DailyProgress
          currentPlays={currentPlays}
          maxPlays={maxDailyPlays}
          earningPerSong={activeInvestment.plan?.earning_per_song || 0}
        />
      )}

      {/* Recent Activity */}
      <RecentActivity transactions={recentTransactions || []} />
    </div>
  )
}
