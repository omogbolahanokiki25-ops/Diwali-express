import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { MusicPlayer } from '@/components/dashboard/music-player'
import { EarningStats } from '@/components/dashboard/earning-stats'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Music, AlertCircle } from 'lucide-react'

export default async function EarnPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/auth/login')

  const today = new Date().toISOString().split('T')[0]

  const [{ data: activeInvestment }, { data: songs }, { data: todayPlays }] = await Promise.all([
    supabase
      .from('user_investments')
      .select('*, plan:investment_plans(*)')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single(),
    supabase
      .from('songs')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false }),
    supabase
      .from('song_plays')
      .select('*, song:songs(*)')
      .eq('user_id', user.id)
      .eq('play_date', today),
  ])

  // If no active investment, show prompt to invest
  if (!activeInvestment) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Earn Money</h1>
          <p className="text-muted-foreground">Listen to songs and earn rewards</p>
        </div>

        <Card className="border-dashed">
          <CardContent className="py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-muted-foreground" />
            </div>
            <CardTitle className="mb-2">No Active Investment</CardTitle>
            <CardDescription className="mb-6">
              You need an active investment plan to start earning. Choose a plan to begin your earning journey.
            </CardDescription>
            <Button asChild>
              <Link href="/dashboard/invest">
                <Music className="w-4 h-4 mr-2" />
                View Investment Plans
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const maxDailyPlays = activeInvestment.plan?.daily_songs || 0
  const currentPlays = todayPlays?.length || 0
  const playedSongIds = todayPlays?.map((play) => play.song_id) || []
  const availableSongs = songs?.filter((song) => !playedSongIds.includes(song.id)) || []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Earn Money</h1>
        <p className="text-muted-foreground">
          Listen to songs and earn {new Intl.NumberFormat('en-NG', {
            style: 'currency',
            currency: 'NGN',
            minimumFractionDigits: 0,
          }).format(activeInvestment.plan?.earning_per_song || 0)} per song
        </p>
      </div>

      {/* Stats */}
      <EarningStats
        currentPlays={currentPlays}
        maxPlays={maxDailyPlays}
        earningPerSong={activeInvestment.plan?.earning_per_song || 0}
      />

      {/* Music Player */}
      {currentPlays < maxDailyPlays ? (
        <MusicPlayer
          songs={availableSongs}
          userId={user.id}
          investmentId={activeInvestment.id}
          earningPerSong={activeInvestment.plan?.earning_per_song || 0}
          remainingPlays={maxDailyPlays - currentPlays}
        />
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
              <Music className="w-8 h-8 text-green-500" />
            </div>
            <CardTitle className="mb-2 text-green-600">All Tasks Completed!</CardTitle>
            <CardDescription>
              {"Great job! You've completed all your songs for today. Come back tomorrow for more earnings."}
            </CardDescription>
          </CardContent>
        </Card>
      )}

      {/* Today's Plays */}
      {todayPlays && todayPlays.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{"Today's Earnings"}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {todayPlays.map((play) => (
                <div
                  key={play.id}
                  className="flex items-center justify-between py-2 border-b last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Music className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{play.song?.title}</p>
                      <p className="text-xs text-muted-foreground">{play.song?.artist || 'Unknown Artist'}</p>
                    </div>
                  </div>
                  <span className="text-green-600 font-semibold">
                    +{new Intl.NumberFormat('en-NG', {
                      style: 'currency',
                      currency: 'NGN',
                      minimumFractionDigits: 0,
                    }).format(play.earned_amount)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
