import { createClient } from '@/lib/supabase/server'
import { ReferralCard } from '@/components/dashboard/referral-card'
import { ReferralList } from '@/components/dashboard/referral-list'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Users, Gift, CheckCircle } from 'lucide-react'

export default async function ReferralsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  const [{ data: profile }, { data: referrals }] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', user.id).single(),
    supabase
      .from('profiles')
      .select('id, full_name, email, created_at')
      .eq('referred_by', user.id)
      .order('created_at', { ascending: false }),
  ])

  const referralCount = profile?.referral_count || 0
  const referralCode = profile?.referral_code || ''

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Referrals</h1>
        <p className="text-muted-foreground">
          Invite friends and unlock withdrawals
        </p>
      </div>

      {/* Referral Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Referrals</p>
                <p className="text-2xl font-bold">{referralCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Withdrawal Status</p>
                <p className="text-lg font-bold">
                  {referralCount >= 3 ? (
                    <span className="text-green-600">Unlocked</span>
                  ) : (
                    <span className="text-muted-foreground">{3 - referralCount} more needed</span>
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
                <Gift className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Bonus per Referral</p>
                <p className="text-2xl font-bold">N100</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress to unlock */}
      {referralCount < 3 && (
        <Card className="border-dashed border-primary/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="flex -space-x-2">
                {[...Array(3)].map((_, i) => (
                  <div
                    key={i}
                    className={`w-10 h-10 rounded-full border-2 border-background flex items-center justify-center ${
                      i < referralCount ? 'bg-primary' : 'bg-muted'
                    }`}
                  >
                    {i < referralCount ? (
                      <CheckCircle className="w-5 h-5 text-primary-foreground" />
                    ) : (
                      <Users className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>
                ))}
              </div>
              <div className="flex-1">
                <p className="font-medium">
                  {referralCount}/3 referrals to unlock withdrawals
                </p>
                <p className="text-sm text-muted-foreground">
                  Invite {3 - referralCount} more friend{3 - referralCount !== 1 ? 's' : ''} to enable withdrawals
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Referral Card */}
      <ReferralCard referralCode={referralCode} />

      {/* Referral List */}
      <ReferralList referrals={referrals || []} />
    </div>
  )
}
