import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { AdminNav } from '@/components/admin/admin-nav'
import { AdminHeader } from '@/components/admin/admin-header'

const ADMIN_USERNAME = 'OK.ANIMATE'

async function verifyAdminSession() {
  const cookieStore = await cookies()
  const adminSession = cookieStore.get('admin_session')

  if (!adminSession?.value) {
    return false
  }

  try {
    const decoded = Buffer.from(adminSession.value, 'base64').toString('utf-8')
    const [username, timestamp] = decoded.split(':')

    // Check if token is valid and not expired (8 hours)
    const tokenTime = parseInt(timestamp)
    const now = Date.now()
    const eightHours = 8 * 60 * 60 * 1000

    if (username !== ADMIN_USERNAME || now - tokenTime > eightHours) {
      return false
    }

    return true
  } catch {
    return false
  }
}

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const isValidAdmin = await verifyAdminSession()
  
  if (!isValidAdmin) {
    redirect('/diwali-secure-portal')
  }

  // Admin profile for display
  const adminProfile = {
    id: 'admin',
    email: 'admin@diwaliexpress.com',
    full_name: 'Administrator',
    is_admin: true,
    referral_code: 'ADMIN',
    referral_count: 0,
    is_blocked: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <AdminHeader profile={adminProfile} />
      <div className="flex">
        <AdminNav />
        <main className="flex-1 p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  )
}
