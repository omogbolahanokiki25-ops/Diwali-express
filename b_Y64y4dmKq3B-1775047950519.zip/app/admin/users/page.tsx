import { createClient } from '@/lib/supabase/server'
import { UsersTable } from '@/components/admin/users-table'

export default async function AdminUsersPage() {
  const supabase = await createClient()

  const { data: users } = await supabase
    .from('profiles')
    .select(`
      *,
      wallets(balance, total_earnings, total_invested, total_withdrawn),
      user_investments(status, plan:investment_plans(name))
    `)
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">User Management</h1>
        <p className="text-muted-foreground">
          View all users with their login info, subscription status, and wallet details
        </p>
      </div>

      <UsersTable users={users || []} />
    </div>
  )
}
