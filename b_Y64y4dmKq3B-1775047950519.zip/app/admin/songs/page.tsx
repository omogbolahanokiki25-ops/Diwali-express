import { createClient } from '@/lib/supabase/server'
import { SongsManager } from '@/components/admin/songs-manager'

export default async function AdminSongsPage() {
  const supabase = await createClient()

  const { data: songs } = await supabase
    .from('songs')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Songs</h1>
        <p className="text-muted-foreground">
          Manage songs for user listening tasks
        </p>
      </div>

      <SongsManager songs={songs || []} />
    </div>
  )
}
