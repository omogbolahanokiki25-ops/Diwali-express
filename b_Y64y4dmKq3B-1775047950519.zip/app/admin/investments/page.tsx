import { createClient } from '@/lib/supabase/server'
import { InvestmentsTable } from '@/components/admin/investments-table'

export default async function AdminInvestmentsPage() {
  const supabase = await createClient()

  const { data: investments } = await supabase
    .from('user_investments')
    .select('*, profiles(full_name, email, phone), plan:investment_plans(name, daily_songs, earning_per_song)')
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Subscription Management</h1>
        <p className="text-muted-foreground">
          Review payment codes and approve or reject subscription requests
        </p>
      </div>

      <InvestmentsTable investments={investments || []} />
    </div>
  )
}
