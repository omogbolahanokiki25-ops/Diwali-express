import { createClient } from '@/lib/supabase/server'
import { WithdrawalsTable } from '@/components/admin/withdrawals-table'

export default async function AdminWithdrawalsPage() {
  const supabase = await createClient()

  const { data: withdrawals } = await supabase
    .from('withdrawals')
    .select('*, profiles(full_name, email, phone, referral_count)')
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Withdrawals</h1>
        <p className="text-muted-foreground">
          Process withdrawal requests
        </p>
      </div>

      <WithdrawalsTable withdrawals={withdrawals || []} />
    </div>
  )
}
