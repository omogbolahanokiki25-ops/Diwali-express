import { SignUpForm } from '@/components/auth/sign-up-form'
import { AuthLayout } from '@/components/auth/auth-layout'

export default function SignUpPage({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string }>
}) {
  return (
    <AuthLayout
      title="Create Account"
      subtitle="Join Diwali Express and start earning today"
    >
      <SignUpForm searchParams={searchParams} />
    </AuthLayout>
  )
}
