import Link from 'next/link'
import { AuthLayout } from '@/components/auth/auth-layout'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Mail, CheckCircle } from 'lucide-react'

export default function SignUpSuccessPage() {
  return (
    <AuthLayout
      title="Check Your Email"
      subtitle="Almost there! Please verify your email address"
    >
      <Card className="border-0 shadow-lg">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <Mail className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-xl">Verification Email Sent</CardTitle>
          <CardDescription>
            {"We've sent a verification link to your email address"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted p-4 rounded-lg space-y-2">
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5" />
              <p className="text-sm">Check your inbox for the verification email</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5" />
              <p className="text-sm">Click the link in the email to verify your account</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5" />
              <p className="text-sm">{"Once verified, you can sign in and start investing"}</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-center">
            {"Didn't receive the email? Check your spam folder or wait a few minutes."}
          </p>
          <Button asChild className="w-full">
            <Link href="/auth/login">Go to Login</Link>
          </Button>
        </CardContent>
      </Card>
    </AuthLayout>
  )
}
