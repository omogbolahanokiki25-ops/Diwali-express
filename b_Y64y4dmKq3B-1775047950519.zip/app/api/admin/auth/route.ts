import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

// Hardcoded admin credentials - only this account can access admin panel
const ADMIN_USERNAME = 'OK.ANIMATE'
const ADMIN_PASSWORD = 'mariam@8'

// Simple token generation (in production, use proper JWT)
function generateToken() {
  const timestamp = Date.now()
  const random = Math.random().toString(36).substring(2, 15)
  return Buffer.from(`${ADMIN_USERNAME}:${timestamp}:${random}`).toString('base64')
}

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json()

    // Validate credentials
    if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
      // Add delay to prevent brute force
      await new Promise(resolve => setTimeout(resolve, 1000))
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // Generate admin token
    const token = generateToken()

    // Set HTTP-only cookie for admin session
    const cookieStore = await cookies()
    cookieStore.set('admin_session', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 8, // 8 hours
      path: '/',
    })

    return NextResponse.json({ 
      success: true, 
      token,
      message: 'Admin access granted' 
    })
  } catch {
    return NextResponse.json(
      { error: 'Server error' },
      { status: 500 }
    )
  }
}

export async function DELETE() {
  // Logout - clear admin session
  const cookieStore = await cookies()
  cookieStore.delete('admin_session')
  
  return NextResponse.json({ success: true })
}
