import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

const ADMIN_USERNAME = 'OK.ANIMATE'

export async function GET() {
  try {
    const cookieStore = await cookies()
    const adminSession = cookieStore.get('admin_session')

    if (!adminSession?.value) {
      return NextResponse.json({ valid: false }, { status: 401 })
    }

    // Decode and verify token
    try {
      const decoded = Buffer.from(adminSession.value, 'base64').toString('utf-8')
      const [username, timestamp] = decoded.split(':')

      // Check if token is valid and not expired (8 hours)
      const tokenTime = parseInt(timestamp)
      const now = Date.now()
      const eightHours = 8 * 60 * 60 * 1000

      if (username !== ADMIN_USERNAME || now - tokenTime > eightHours) {
        return NextResponse.json({ valid: false }, { status: 401 })
      }

      return NextResponse.json({ valid: true, username })
    } catch {
      return NextResponse.json({ valid: false }, { status: 401 })
    }
  } catch {
    return NextResponse.json({ valid: false }, { status: 500 })
  }
}
