'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { createClient } from '@/lib/supabase/client'
import { Profile } from '@/lib/types/database'
import { Search, Ban, CheckCircle, Eye, Copy, Check } from 'lucide-react'

interface UserWithDetails extends Profile {
  wallets: { balance: number; total_earnings: number; total_invested: number; total_withdrawn: number } | null
  user_investments: { status: string; plan: { name: string } | null }[] | null
}

interface UsersTableProps {
  users: UserWithDetails[]
}

export function UsersTable({ users }: UsersTableProps) {
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState<string | null>(null)
  const [selectedUser, setSelectedUser] = useState<UserWithDetails | null>(null)
  const [copied, setCopied] = useState<string | null>(null)
  const router = useRouter()

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const copyText = (text: string, field: string) => {
    navigator.clipboard.writeText(text)
    setCopied(field)
    setTimeout(() => setCopied(null), 2000)
  }

  const toggleBlock = async (userId: string, isBlocked: boolean) => {
    setLoading(userId)
    const supabase = createClient()

    await supabase
      .from('profiles')
      .update({ is_blocked: !isBlocked })
      .eq('id', userId)

    // Create notification
    await supabase.from('notifications').insert({
      user_id: userId,
      title: isBlocked ? 'Account Unblocked' : 'Account Blocked',
      message: isBlocked 
        ? 'Your account has been unblocked. You can now access all features.'
        : 'Your account has been blocked. Please contact support.',
      type: isBlocked ? 'success' : 'error',
    })

    router.refresh()
    setLoading(null)
  }

  const getActiveSubscription = (user: UserWithDetails) => {
    const active = user.user_investments?.find(inv => inv.status === 'active')
    return active?.plan?.name || 'None'
  }

  const filteredUsers = users.filter(
    (user) =>
      user.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      user.email.toLowerCase().includes(search.toLowerCase()) ||
      user.phone?.includes(search) ||
      user.referral_code.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle>All Users ({users.length})</CardTitle>
              <CardDescription>
                View user details, login info, and subscription status
              </CardDescription>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Referral Code</TableHead>
                  <TableHead>Subscription</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Referrals</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      No users found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{user.full_name || 'N/A'}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm">{user.phone || 'N/A'}</span>
                      </TableCell>
                      <TableCell>
                        <code className="text-xs bg-muted px-2 py-1 rounded">
                          {user.referral_code}
                        </code>
                      </TableCell>
                      <TableCell>
                        <span className={`text-sm font-medium ${getActiveSubscription(user) !== 'None' ? 'text-primary' : 'text-muted-foreground'}`}>
                          {getActiveSubscription(user)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="font-medium">{formatCurrency(user.wallets?.balance || 0)}</span>
                      </TableCell>
                      <TableCell>
                        <span className={user.referral_count >= 3 ? 'text-green-600 font-medium' : ''}>
                          {user.referral_count}
                        </span>
                      </TableCell>
                      <TableCell>
                        {user.is_blocked ? (
                          <span className="px-2 py-0.5 rounded-full bg-red-500/10 text-red-500 text-xs">
                            Blocked
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-green-500/10 text-green-500 text-xs">
                            Active
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedUser(user)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleBlock(user.id, user.is_blocked)}
                            disabled={loading === user.id}
                          >
                            {user.is_blocked ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <Ban className="w-4 h-4 text-red-500" />
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* User Detail Dialog */}
      <Dialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription>
              Complete user information and account details
            </DialogDescription>
          </DialogHeader>

          {selectedUser && (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {/* Login Information */}
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm">Login Information</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Email:</span>
                    <div className="flex items-center gap-1">
                      <span className="text-sm font-medium">{selectedUser.email}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => copyText(selectedUser.email, 'email')}
                      >
                        {copied === 'email' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Phone:</span>
                    <div className="flex items-center gap-1">
                      <span className="text-sm font-medium">{selectedUser.phone || 'N/A'}</span>
                      {selectedUser.phone && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => copyText(selectedUser.phone!, 'phone')}
                        >
                          {copied === 'phone' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Full Name:</span>
                    <span className="text-sm font-medium">{selectedUser.full_name || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Joined:</span>
                    <span className="text-sm">{formatDate(selectedUser.created_at)}</span>
                  </div>
                </div>
              </div>

              {/* Referral Info */}
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm text-primary">Referral Information</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Referral Code:</span>
                    <div className="flex items-center gap-1">
                      <code className="bg-primary/10 text-primary px-2 py-1 rounded font-bold text-sm">
                        {selectedUser.referral_code}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => copyText(selectedUser.referral_code, 'referral')}
                      >
                        {copied === 'referral' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Referral Count:</span>
                    <span className={`text-sm font-bold ${selectedUser.referral_count >= 3 ? 'text-green-600' : 'text-yellow-600'}`}>
                      {selectedUser.referral_count} / 3 {selectedUser.referral_count >= 3 ? '(Can Withdraw)' : '(Cannot Withdraw Yet)'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Subscription Info */}
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm">Subscription Status</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Active Plan:</span>
                    <span className="text-sm font-bold text-primary">
                      {getActiveSubscription(selectedUser)}
                    </span>
                  </div>
                  {selectedUser.user_investments && selectedUser.user_investments.length > 0 && (
                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground mb-1">All Subscriptions:</p>
                      {selectedUser.user_investments.map((inv, idx) => (
                        <div key={idx} className="flex justify-between text-xs">
                          <span>{inv.plan?.name || 'Unknown'}</span>
                          <span className={inv.status === 'active' ? 'text-green-600' : inv.status === 'pending' ? 'text-yellow-600' : 'text-muted-foreground'}>
                            {inv.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Wallet Info */}
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm">Wallet Information</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-muted-foreground">Balance:</span>
                  <span className="font-bold text-primary">{formatCurrency(selectedUser.wallets?.balance || 0)}</span>
                  <span className="text-muted-foreground">Total Earnings:</span>
                  <span className="font-medium">{formatCurrency(selectedUser.wallets?.total_earnings || 0)}</span>
                  <span className="text-muted-foreground">Total Invested:</span>
                  <span className="font-medium">{formatCurrency(selectedUser.wallets?.total_invested || 0)}</span>
                  <span className="text-muted-foreground">Total Withdrawn:</span>
                  <span className="font-medium">{formatCurrency(selectedUser.wallets?.total_withdrawn || 0)}</span>
                </div>
              </div>

              {/* Account Status */}
              <div className="flex justify-between items-center p-3 rounded-lg border">
                <span className="text-sm font-medium">Account Status:</span>
                {selectedUser.is_blocked ? (
                  <span className="px-3 py-1 rounded-full bg-red-500/10 text-red-500 text-sm font-medium">
                    Blocked
                  </span>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-green-500/10 text-green-500 text-sm font-medium">
                    Active
                  </span>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button
                  variant={selectedUser.is_blocked ? 'default' : 'destructive'}
                  className="flex-1"
                  onClick={() => {
                    toggleBlock(selectedUser.id, selectedUser.is_blocked)
                    setSelectedUser(null)
                  }}
                >
                  {selectedUser.is_blocked ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Unblock User
                    </>
                  ) : (
                    <>
                      <Ban className="w-4 h-4 mr-2" />
                      Block User
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
