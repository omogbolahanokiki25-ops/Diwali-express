'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { createClient } from '@/lib/supabase/client'
import { Withdrawal } from '@/lib/types/database'
import { CheckCircle, XCircle, Clock, Loader2 } from 'lucide-react'

interface WithdrawalWithProfile extends Withdrawal {
  profiles: { 
    full_name: string | null
    email: string
    phone: string | null
    referral_count: number 
  } | null
}

interface WithdrawalsTableProps {
  withdrawals: WithdrawalWithProfile[]
}

export function WithdrawalsTable({ withdrawals }: WithdrawalsTableProps) {
  const [statusFilter, setStatusFilter] = useState<string>('pending')
  const [loading, setLoading] = useState<string | null>(null)
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalWithProfile | null>(null)
  const [adminNote, setAdminNote] = useState('')
  const router = useRouter()

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const processWithdrawal = async (status: 'approved' | 'rejected') => {
    if (!selectedWithdrawal) return

    setLoading(selectedWithdrawal.id)
    const supabase = createClient()

    // Update withdrawal
    await supabase
      .from('withdrawals')
      .update({
        status,
        admin_note: adminNote || null,
        processed_at: new Date().toISOString(),
      })
      .eq('id', selectedWithdrawal.id)

    // If approved, deduct from wallet and create transaction
    if (status === 'approved') {
      // Get current wallet
      const { data: wallet } = await supabase
        .from('wallets')
        .select('balance, total_withdrawn')
        .eq('user_id', selectedWithdrawal.user_id)
        .single()

      if (wallet) {
        await supabase
          .from('wallets')
          .update({
            balance: wallet.balance - selectedWithdrawal.amount,
            total_withdrawn: wallet.total_withdrawn + selectedWithdrawal.amount,
          })
          .eq('user_id', selectedWithdrawal.user_id)
      }

      await supabase.from('transactions').insert({
        user_id: selectedWithdrawal.user_id,
        type: 'withdrawal',
        amount: selectedWithdrawal.amount,
        description: 'Withdrawal to Smartcash PSB',
        reference_id: selectedWithdrawal.id,
      })
    }

    // Create notification
    await supabase.from('notifications').insert({
      user_id: selectedWithdrawal.user_id,
      title: status === 'approved' ? 'Withdrawal Approved' : 'Withdrawal Rejected',
      message:
        status === 'approved'
          ? `Your withdrawal of ${formatCurrency(selectedWithdrawal.amount)} has been approved and processed.`
          : `Your withdrawal request was rejected. ${adminNote ? `Reason: ${adminNote}` : ''}`,
      type: status === 'approved' ? 'success' : 'error',
    })

    setSelectedWithdrawal(null)
    setAdminNote('')
    router.refresh()
    setLoading(null)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs">
            <CheckCircle className="w-3 h-3" />
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-600 text-xs">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        )
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/10 text-red-600 text-xs">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        )
      default:
        return <span className="text-xs text-muted-foreground">{status}</span>
    }
  }

  const filteredWithdrawals = withdrawals.filter(
    (w) => statusFilter === 'all' || w.status === statusFilter
  )

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Withdrawals ({filteredWithdrawals.length})</CardTitle>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Bank Details</TableHead>
                  <TableHead>Referrals</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredWithdrawals.map((withdrawal) => (
                  <TableRow key={withdrawal.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{withdrawal.profiles?.full_name || 'N/A'}</p>
                        <p className="text-xs text-muted-foreground">{withdrawal.profiles?.email}</p>
                      </div>
                    </TableCell>
                    <TableCell className="font-semibold">
                      {formatCurrency(withdrawal.amount)}
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">{withdrawal.bank_name}</p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {withdrawal.account_number}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className={withdrawal.profiles?.referral_count >= 3 ? 'text-green-600' : 'text-red-600'}>
                        {withdrawal.profiles?.referral_count || 0}
                      </span>
                    </TableCell>
                    <TableCell>{formatDate(withdrawal.created_at)}</TableCell>
                    <TableCell>{getStatusBadge(withdrawal.status)}</TableCell>
                    <TableCell>
                      {withdrawal.status === 'pending' && (
                        <Button
                          size="sm"
                          onClick={() => setSelectedWithdrawal(withdrawal)}
                        >
                          Process
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Process Dialog */}
      <Dialog open={!!selectedWithdrawal} onOpenChange={() => setSelectedWithdrawal(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Process Withdrawal</DialogTitle>
            <DialogDescription>
              Review and process this withdrawal request
            </DialogDescription>
          </DialogHeader>

          {selectedWithdrawal && (
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">User</span>
                  <span className="font-medium">{selectedWithdrawal.profiles?.full_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Amount</span>
                  <span className="font-bold text-lg">{formatCurrency(selectedWithdrawal.amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Bank</span>
                  <span>{selectedWithdrawal.bank_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Account</span>
                  <span className="font-mono">{selectedWithdrawal.account_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Referrals</span>
                  <span className={selectedWithdrawal.profiles?.referral_count >= 3 ? 'text-green-600' : 'text-red-600'}>
                    {selectedWithdrawal.profiles?.referral_count || 0} / 3
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="note">Admin Note (Optional)</Label>
                <Textarea
                  id="note"
                  placeholder="Add a note for this withdrawal..."
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  className="flex-1"
                  onClick={() => processWithdrawal('approved')}
                  disabled={loading === selectedWithdrawal.id}
                >
                  {loading === selectedWithdrawal.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approve
                    </>
                  )}
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  onClick={() => processWithdrawal('rejected')}
                  disabled={loading === selectedWithdrawal.id}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
