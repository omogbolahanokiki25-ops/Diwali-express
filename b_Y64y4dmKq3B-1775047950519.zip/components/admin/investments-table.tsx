'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { createClient } from '@/lib/supabase/client'
import { UserInvestment } from '@/lib/types/database'
import { CheckCircle, XCircle, Clock, Loader2, Eye, Copy, Check } from 'lucide-react'

interface InvestmentWithRelations extends UserInvestment {
  profiles: { full_name: string | null; email: string; phone: string | null } | null
  plan: { name: string; daily_songs: number; earning_per_song: number } | null
}

interface InvestmentsTableProps {
  investments: InvestmentWithRelations[]
}

export function InvestmentsTable({ investments }: InvestmentsTableProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [loading, setLoading] = useState<string | null>(null)
  const [selectedInvestment, setSelectedInvestment] = useState<InvestmentWithRelations | null>(null)
  const [copied, setCopied] = useState(false)
  const router = useRouter()

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const approveInvestment = async (investment: InvestmentWithRelations) => {
    setLoading(investment.id)
    const supabase = createClient()

    try {
      // Update investment status
      await supabase
        .from('user_investments')
        .update({
          status: 'active',
          activated_at: new Date().toISOString(),
        })
        .eq('id', investment.id)

      // Update wallet total invested
      const { data: wallet } = await supabase
        .from('wallets')
        .select('total_invested')
        .eq('user_id', investment.user_id)
        .single()

      if (wallet) {
        await supabase
          .from('wallets')
          .update({
            total_invested: wallet.total_invested + investment.amount,
          })
          .eq('user_id', investment.user_id)
      }

      // Create transaction
      await supabase.from('transactions').insert({
        user_id: investment.user_id,
        type: 'investment',
        amount: investment.amount,
        description: `Investment in ${investment.plan?.name} - Code: ${investment.payment_reference}`,
        reference_id: investment.id,
      })

      // Create notification
      await supabase.from('notifications').insert({
        user_id: investment.user_id,
        title: 'Subscription Activated!',
        message: `Your ${investment.plan?.name} subscription has been approved. You can now start earning by listening to songs!`,
        type: 'success',
      })

      setSelectedInvestment(null)
      router.refresh()
    } catch (error) {
      console.error('Error approving investment:', error)
    } finally {
      setLoading(null)
    }
  }

  const rejectInvestment = async (investment: InvestmentWithRelations) => {
    setLoading(investment.id)
    const supabase = createClient()

    try {
      await supabase
        .from('user_investments')
        .update({ status: 'cancelled' })
        .eq('id', investment.id)

      await supabase.from('notifications').insert({
        user_id: investment.user_id,
        title: 'Subscription Rejected',
        message: `Your ${investment.plan?.name} subscription request was not approved. Payment code: ${investment.payment_reference}. Please contact support if you believe this is an error.`,
        type: 'error',
      })

      setSelectedInvestment(null)
      router.refresh()
    } catch (error) {
      console.error('Error rejecting investment:', error)
    } finally {
      setLoading(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs">
            <CheckCircle className="w-3 h-3" />
            Active
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-600 text-xs">
            <Clock className="w-3 h-3" />
            Pending Approval
          </span>
        )
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/10 text-red-600 text-xs">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        )
      default:
        return <span className="text-xs text-muted-foreground">{status}</span>
    }
  }

  const filteredInvestments = investments.filter(
    (inv) => statusFilter === 'all' || inv.status === statusFilter
  )

  const pendingCount = investments.filter(i => i.status === 'pending').length

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                Subscription Requests
                {pendingCount > 0 && (
                  <span className="px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-600 text-xs">
                    {pendingCount} pending
                  </span>
                )}
              </CardTitle>
              <CardDescription>
                Review and approve user subscription payments
              </CardDescription>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="cancelled">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Payment Code</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvestments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No subscription requests found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvestments.map((investment) => (
                    <TableRow key={investment.id} className={investment.status === 'pending' ? 'bg-yellow-50/50' : ''}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{investment.profiles?.full_name || 'N/A'}</p>
                          <p className="text-xs text-muted-foreground">{investment.profiles?.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="font-medium">{investment.plan?.name}</span>
                      </TableCell>
                      <TableCell>
                        <span className="font-bold text-primary">{formatCurrency(investment.amount)}</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <code className="text-xs bg-primary/10 text-primary px-2 py-1 rounded font-bold">
                            {investment.payment_reference || 'N/A'}
                          </code>
                          {investment.payment_reference && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => copyCode(investment.payment_reference!)}
                            >
                              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                            </Button>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{formatDate(investment.created_at)}</TableCell>
                      <TableCell>{getStatusBadge(investment.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedInvestment(investment)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          {investment.status === 'pending' && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => approveInvestment(investment)}
                                disabled={loading === investment.id}
                              >
                                {loading === investment.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <CheckCircle className="w-4 h-4" />
                                )}
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => rejectInvestment(investment)}
                                disabled={loading === investment.id}
                              >
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={!!selectedInvestment} onOpenChange={() => setSelectedInvestment(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Subscription Details</DialogTitle>
            <DialogDescription>
              Review the payment information before approval
            </DialogDescription>
          </DialogHeader>

          {selectedInvestment && (
            <div className="space-y-4">
              {/* User Info */}
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm">User Information</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="font-medium">{selectedInvestment.profiles?.full_name || 'N/A'}</span>
                  <span className="text-muted-foreground">Email:</span>
                  <span className="font-medium">{selectedInvestment.profiles?.email}</span>
                  <span className="text-muted-foreground">Phone:</span>
                  <span className="font-medium">{selectedInvestment.profiles?.phone || 'N/A'}</span>
                </div>
              </div>

              {/* Payment Info */}
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm text-primary">Payment Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Plan:</span>
                    <span className="font-bold">{selectedInvestment.plan?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-bold text-primary">{formatCurrency(selectedInvestment.amount)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Payment Code:</span>
                    <code className="bg-primary/10 text-primary px-2 py-1 rounded font-bold">
                      {selectedInvestment.payment_reference}
                    </code>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Submitted:</span>
                    <span>{formatDate(selectedInvestment.created_at)}</span>
                  </div>
                </div>
              </div>

              {/* Plan Benefits */}
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-sm">Plan Benefits</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-muted-foreground">Daily Songs:</span>
                  <span className="font-medium">{selectedInvestment.plan?.daily_songs}</span>
                  <span className="text-muted-foreground">Per Song:</span>
                  <span className="font-medium">{formatCurrency(selectedInvestment.plan?.earning_per_song || 0)}</span>
                  <span className="text-muted-foreground">Daily Earnings:</span>
                  <span className="font-bold text-primary">
                    {formatCurrency((selectedInvestment.plan?.daily_songs || 0) * (selectedInvestment.plan?.earning_per_song || 0))}
                  </span>
                </div>
              </div>

              {/* Actions */}
              {selectedInvestment.status === 'pending' && (
                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    onClick={() => approveInvestment(selectedInvestment)}
                    disabled={loading === selectedInvestment.id}
                  >
                    {loading === selectedInvestment.id ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <CheckCircle className="w-4 h-4 mr-2" />
                    )}
                    Approve Subscription
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => rejectInvestment(selectedInvestment)}
                    disabled={loading === selectedInvestment.id}
                  >
                    <XCircle className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
