'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { createClient } from '@/lib/supabase/client'
import { Song } from '@/lib/types/database'
import { Plus, Music, Trash2, Eye, EyeOff, Loader2 } from 'lucide-react'

interface SongsManagerProps {
  songs: Song[]
}

export function SongsManager({ songs }: SongsManagerProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: '',
    artist: '',
    duration_seconds: 30,
  })
  const router = useRouter()

  const addSong = async () => {
    if (!formData.title.trim()) return

    setLoading('add')
    const supabase = createClient()

    await supabase.from('songs').insert({
      title: formData.title.trim(),
      artist: formData.artist.trim() || null,
      duration_seconds: formData.duration_seconds,
      is_active: true,
    })

    setFormData({ title: '', artist: '', duration_seconds: 30 })
    setOpen(false)
    router.refresh()
    setLoading(null)
  }

  const toggleActive = async (song: Song) => {
    setLoading(song.id)
    const supabase = createClient()

    await supabase
      .from('songs')
      .update({ is_active: !song.is_active })
      .eq('id', song.id)

    router.refresh()
    setLoading(null)
  }

  const deleteSong = async (songId: string) => {
    if (!confirm('Are you sure you want to delete this song?')) return

    setLoading(songId)
    const supabase = createClient()

    await supabase.from('songs').delete().eq('id', songId)

    router.refresh()
    setLoading(null)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Songs Library ({songs.length})</CardTitle>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Song
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Song</DialogTitle>
                <DialogDescription>
                  Add a new song to the library for users to listen to
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Song Title *</Label>
                  <Input
                    id="title"
                    placeholder="Enter song title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="artist">Artist</Label>
                  <Input
                    id="artist"
                    placeholder="Enter artist name"
                    value={formData.artist}
                    onChange={(e) => setFormData({ ...formData, artist: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (seconds)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min={10}
                    max={300}
                    value={formData.duration_seconds}
                    onChange={(e) =>
                      setFormData({ ...formData, duration_seconds: parseInt(e.target.value) || 30 })
                    }
                  />
                </div>
                <Button
                  className="w-full"
                  onClick={addSong}
                  disabled={!formData.title.trim() || loading === 'add'}
                >
                  {loading === 'add' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Song
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Song</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Added</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {songs.map((song) => (
                <TableRow key={song.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Music className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{song.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {song.artist || 'Unknown Artist'}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{song.duration_seconds}s</TableCell>
                  <TableCell>{formatDate(song.created_at)}</TableCell>
                  <TableCell>
                    {song.is_active ? (
                      <span className="px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs">
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-1 rounded-full bg-muted text-muted-foreground text-xs">
                        Hidden
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleActive(song)}
                        disabled={loading === song.id}
                      >
                        {song.is_active ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteSong(song.id)}
                        disabled={loading === song.id}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
