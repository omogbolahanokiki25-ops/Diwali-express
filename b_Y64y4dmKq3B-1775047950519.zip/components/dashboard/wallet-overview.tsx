import { Card, CardContent } from '@/components/ui/card'
import { Wallet as WalletType } from '@/lib/types/database'
import { Wallet, TrendingUp, ArrowDownToLine, CreditCard } from 'lucide-react'

interface WalletOverviewProps {
  wallet: WalletType | null
}

export function WalletOverview({ wallet }: WalletOverviewProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {/* Available Balance */}
      <Card className="col-span-2 bg-gradient-to-br from-primary/10 to-accent/10">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center">
              <Wallet className="w-7 h-7 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <p className="text-3xl font-bold">{formatCurrency(wallet?.balance || 0)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Total Earnings */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Earnings</p>
              <p className="text-lg font-bold">{formatCurrency(wallet?.total_earnings || 0)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Total Invested */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Invested</p>
              <p className="text-lg font-bold">{formatCurrency(wallet?.total_invested || 0)}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
