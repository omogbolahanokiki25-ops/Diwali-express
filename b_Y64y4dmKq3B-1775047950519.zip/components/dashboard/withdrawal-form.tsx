'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { createClient } from '@/lib/supabase/client'
import { ArrowDownToLine, Loader2, AlertCircle, CheckCircle, Users, Wallet } from 'lucide-react'

interface WithdrawalFormProps {
  userId: string
  balance: number
  referralCount: number
  canWithdraw: boolean
}

const MIN_WITHDRAWAL = 5000
const PAYMENT_ACCOUNT = {
  bankName: 'Smartcash PSB',
  accountNumber: '8086240621',
}

export function WithdrawalForm({ userId, balance, referralCount, canWithdraw }: WithdrawalFormProps) {
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const handleWithdraw = async () => {
    const withdrawAmount = parseFloat(amount)
    if (!withdrawAmount || withdrawAmount < MIN_WITHDRAWAL || withdrawAmount > balance) return

    setLoading(true)

    const supabase = createClient()

    try {
      // Create withdrawal request
      const { error } = await supabase.from('withdrawals').insert({
        user_id: userId,
        amount: withdrawAmount,
        bank_name: PAYMENT_ACCOUNT.bankName,
        account_number: PAYMENT_ACCOUNT.accountNumber,
        status: 'pending',
      })

      if (error) throw error

      // Create notification
      await supabase.from('notifications').insert({
        user_id: userId,
        title: 'Withdrawal Request Submitted',
        message: `Your withdrawal request of ${formatCurrency(withdrawAmount)} is pending approval.`,
        type: 'info',
      })

      setSuccess(true)
      setAmount('')
      
      setTimeout(() => {
        setSuccess(false)
        router.refresh()
      }, 2000)
    } catch (error) {
      console.error('Error creating withdrawal:', error)
    } finally {
      setLoading(false)
    }
  }

  // Show requirements if cannot withdraw
  if (!canWithdraw) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowDownToLine className="w-5 h-5 text-primary" />
            Withdraw Funds
          </CardTitle>
          <CardDescription>
            Complete the requirements below to enable withdrawals
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            {/* Balance Requirement */}
            <div className={`flex items-center gap-3 p-3 rounded-lg ${balance >= MIN_WITHDRAWAL ? 'bg-green-500/10' : 'bg-muted'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${balance >= MIN_WITHDRAWAL ? 'bg-green-500/20' : 'bg-muted-foreground/20'}`}>
                {balance >= MIN_WITHDRAWAL ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Wallet className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Minimum Balance</p>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(balance)} / {formatCurrency(MIN_WITHDRAWAL)}
                </p>
              </div>
              {balance >= MIN_WITHDRAWAL && (
                <span className="text-xs text-green-500 font-medium">Complete</span>
              )}
            </div>

            {/* Referral Requirement */}
            <div className={`flex items-center gap-3 p-3 rounded-lg ${referralCount >= 3 ? 'bg-green-500/10' : 'bg-muted'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${referralCount >= 3 ? 'bg-green-500/20' : 'bg-muted-foreground/20'}`}>
                {referralCount >= 3 ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Users className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Referral Requirement</p>
                <p className="text-xs text-muted-foreground">
                  {referralCount} / 3 referrals
                </p>
              </div>
              {referralCount >= 3 ? (
                <span className="text-xs text-green-500 font-medium">Complete</span>
              ) : (
                <span className="text-xs text-muted-foreground">{3 - referralCount} more needed</span>
              )}
            </div>
          </div>

          <Button variant="outline" className="w-full" asChild>
            <a href="/dashboard/referrals">
              <Users className="w-4 h-4 mr-2" />
              Invite Friends
            </a>
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ArrowDownToLine className="w-5 h-5 text-primary" />
          Withdraw Funds
        </CardTitle>
        <CardDescription>
          Withdraw to Smartcash PSB - {PAYMENT_ACCOUNT.accountNumber}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {success && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 text-green-600">
            <CheckCircle className="w-4 h-4" />
            <span className="text-sm font-medium">Withdrawal request submitted successfully!</span>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="amount">Withdrawal Amount</Label>
          <Input
            id="amount"
            type="number"
            placeholder={`Min ${formatCurrency(MIN_WITHDRAWAL)}`}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            min={MIN_WITHDRAWAL}
            max={balance}
          />
          <p className="text-xs text-muted-foreground">
            Available: {formatCurrency(balance)} | Minimum: {formatCurrency(MIN_WITHDRAWAL)}
          </p>
        </div>

        <Button
          className="w-full"
          onClick={handleWithdraw}
          disabled={
            loading ||
            !amount ||
            parseFloat(amount) < MIN_WITHDRAWAL ||
            parseFloat(amount) > balance
          }
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <ArrowDownToLine className="w-4 h-4 mr-2" />
              Request Withdrawal
            </>
          )}
        </Button>

        <div className="flex items-start gap-2 p-3 rounded-lg bg-muted text-sm">
          <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5" />
          <p className="text-muted-foreground">
            Withdrawals are processed within 24-48 hours. You will be notified once approved.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
