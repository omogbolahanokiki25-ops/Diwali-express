import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Transaction } from '@/lib/types/database'
import { TrendingUp, TrendingDown, Gift, CreditCard, Users } from 'lucide-react'

interface RecentActivityProps {
  transactions: Transaction[]
}

export function RecentActivity({ transactions }: RecentActivityProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'earning':
        return <TrendingUp className="w-4 h-4 text-green-500" />
      case 'withdrawal':
        return <TrendingDown className="w-4 h-4 text-red-500" />
      case 'bonus':
        return <Gift className="w-4 h-4 text-purple-500" />
      case 'investment':
        return <CreditCard className="w-4 h-4 text-blue-500" />
      case 'referral_bonus':
        return <Users className="w-4 h-4 text-orange-500" />
      default:
        return <TrendingUp className="w-4 h-4 text-muted-foreground" />
    }
  }

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'earning':
      case 'bonus':
      case 'referral_bonus':
        return 'text-green-600'
      case 'withdrawal':
      case 'investment':
        return 'text-foreground'
      default:
        return 'text-foreground'
    }
  }

  const getTransactionSign = (type: string) => {
    switch (type) {
      case 'earning':
      case 'bonus':
      case 'referral_bonus':
        return '+'
      case 'withdrawal':
        return '-'
      default:
        return ''
    }
  }

  if (transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p>No recent activity</p>
            <p className="text-sm">Your transactions will appear here</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between py-2 border-b last:border-0"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                  {getTransactionIcon(transaction.type)}
                </div>
                <div>
                  <p className="text-sm font-medium capitalize">
                    {transaction.type.replace('_', ' ')}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(transaction.created_at)}
                  </p>
                </div>
              </div>
              <span className={`font-semibold ${getTransactionColor(transaction.type)}`}>
                {getTransactionSign(transaction.type)}
                {formatCurrency(transaction.amount)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
