import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { UserInvestment } from '@/lib/types/database'
import { CheckCircle, Clock, Music } from 'lucide-react'

interface ActiveInvestmentProps {
  investment: UserInvestment
}

export function ActiveInvestment({ investment }: ActiveInvestmentProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs font-medium">
            <CheckCircle className="w-3 h-3" />
            Active
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-600 text-xs font-medium">
            <Clock className="w-3 h-3" />
            Pending Approval
          </span>
        )
      default:
        return null
    }
  }

  return (
    <Card className="border-primary/30 bg-primary/5">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Music className="w-5 h-5 text-primary" />
            Your Current Plan
          </CardTitle>
          {getStatusBadge(investment.status)}
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Plan</p>
            <p className="font-semibold">{investment.plan?.name}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Investment</p>
            <p className="font-semibold">{formatCurrency(investment.amount)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Daily Songs</p>
            <p className="font-semibold">{investment.plan?.daily_songs}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Per Song</p>
            <p className="font-semibold">{formatCurrency(investment.plan?.earning_per_song || 0)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
