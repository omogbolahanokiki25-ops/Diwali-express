import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Music, TrendingUp, Target } from 'lucide-react'

interface EarningStatsProps {
  currentPlays: number
  maxPlays: number
  earningPerSong: number
}

export function EarningStats({ currentPlays, maxPlays, earningPerSong }: EarningStatsProps) {
  const progress = maxPlays > 0 ? (currentPlays / maxPlays) * 100 : 0
  const earnedToday = currentPlays * earningPerSong
  const totalPossible = maxPlays * earningPerSong
  const remaining = totalPossible - earnedToday

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="space-y-4">
      {/* Progress Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Daily Progress</span>
            <span className="text-sm text-muted-foreground">
              {currentPlays} / {maxPlays} songs
            </span>
          </div>
          <Progress value={progress} className="h-3" />
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center mx-auto mb-2">
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-lg font-bold text-green-600">{formatCurrency(earnedToday)}</p>
            <p className="text-xs text-muted-foreground">Earned Today</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center mx-auto mb-2">
              <Music className="w-5 h-5 text-blue-500" />
            </div>
            <p className="text-lg font-bold">{maxPlays - currentPlays}</p>
            <p className="text-xs text-muted-foreground">Songs Left</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center mx-auto mb-2">
              <Target className="w-5 h-5 text-purple-500" />
            </div>
            <p className="text-lg font-bold">{formatCurrency(remaining)}</p>
            <p className="text-xs text-muted-foreground">Remaining</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
