import { Card, CardContent } from '@/components/ui/card'
import { Wallet, UserInvestment } from '@/lib/types/database'
import { Wallet as WalletIcon, TrendingUp, Music, Users } from 'lucide-react'

interface DashboardStatsProps {
  wallet: Wallet | null
  activeInvestment: UserInvestment | null
  currentPlays: number
  maxDailyPlays: number
  referralCount: number
}

export function DashboardStats({
  wallet,
  activeInvestment,
  currentPlays,
  maxDailyPlays,
  referralCount,
}: DashboardStatsProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {/* Balance */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <WalletIcon className="w-5 h-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Balance</p>
              <p className="text-lg font-bold truncate">
                {formatCurrency(wallet?.balance || 0)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Total Earnings */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Earnings</p>
              <p className="text-lg font-bold truncate">
                {formatCurrency(wallet?.total_earnings || 0)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Progress */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Music className="w-5 h-5 text-blue-500" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Today</p>
              <p className="text-lg font-bold">
                {currentPlays}/{maxDailyPlays}
                <span className="text-xs font-normal text-muted-foreground ml-1">songs</span>
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Referrals */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-500" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Referrals</p>
              <p className="text-lg font-bold">
                {referralCount}
                <span className="text-xs font-normal text-muted-foreground ml-1">
                  {referralCount >= 3 ? '(unlocked)' : '/3'}
                </span>
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
