'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Copy, Check, Share2 } from 'lucide-react'

interface ReferralCardProps {
  referralCode: string
}

export function ReferralCard({ referralCode }: ReferralCardProps) {
  const [copied, setCopied] = useState(false)

  const referralLink = typeof window !== 'undefined' 
    ? `${window.location.origin}/auth/sign-up?ref=${referralCode}`
    : `/auth/sign-up?ref=${referralCode}`

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const shareLink = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Diwali Express',
          text: 'Start earning by listening to music! Use my referral code to sign up.',
          url: referralLink,
        })
      } catch (error) {
        console.error('Error sharing:', error)
      }
    } else {
      copyLink()
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Share2 className="w-5 h-5 text-primary" />
          Your Referral Code
        </CardTitle>
        <CardDescription>
          Share this code with friends to earn bonuses
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Referral Code */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Referral Code</label>
          <div className="flex gap-2">
            <Input 
              value={referralCode} 
              readOnly 
              className="font-mono text-lg font-bold text-center"
            />
            <Button variant="outline" onClick={copyCode}>
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Referral Link */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Referral Link</label>
          <div className="flex gap-2">
            <Input 
              value={referralLink} 
              readOnly 
              className="text-sm"
            />
            <Button variant="outline" onClick={copyLink}>
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Share Button */}
        <Button className="w-full" onClick={shareLink}>
          <Share2 className="w-4 h-4 mr-2" />
          Share Referral Link
        </Button>
      </CardContent>
    </Card>
  )
}
