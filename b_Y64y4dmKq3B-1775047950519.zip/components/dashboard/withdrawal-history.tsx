import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Withdrawal } from '@/lib/types/database'
import { Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react'

interface WithdrawalHistoryProps {
  withdrawals: Withdrawal[]
}

export function WithdrawalHistory({ withdrawals }: WithdrawalHistoryProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs font-medium">
            <CheckCircle className="w-3 h-3" />
            Completed
          </span>
        )
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/10 text-green-600 text-xs font-medium">
            <CheckCircle className="w-3 h-3" />
            Approved
          </span>
        )
      case 'processing':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-blue-500/10 text-blue-600 text-xs font-medium">
            <Loader2 className="w-3 h-3 animate-spin" />
            Processing
          </span>
        )
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/10 text-red-600 text-xs font-medium">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-600 text-xs font-medium">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        )
    }
  }

  if (withdrawals.length === 0) {
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Withdrawal History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {withdrawals.map((withdrawal) => (
            <div
              key={withdrawal.id}
              className="flex items-center justify-between py-3 border-b last:border-0"
            >
              <div>
                <p className="font-semibold">{formatCurrency(withdrawal.amount)}</p>
                <p className="text-xs text-muted-foreground">
                  {formatDate(withdrawal.created_at)} • {withdrawal.bank_name}
                </p>
                {withdrawal.admin_note && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Note: {withdrawal.admin_note}
                  </p>
                )}
              </div>
              {getStatusBadge(withdrawal.status)}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
