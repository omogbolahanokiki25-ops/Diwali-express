'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Song } from '@/lib/types/database'
import { createClient } from '@/lib/supabase/client'
import { Play, Pause, SkipForward, Music, Loader2, CheckCircle } from 'lucide-react'

interface MusicPlayerProps {
  songs: Song[]
  userId: string
  investmentId: string
  earningPerSong: number
  remainingPlays: number
}

const PLAY_DURATION = 30 // seconds

export function MusicPlayer({
  songs,
  userId,
  investmentId,
  earningPerSong,
  remainingPlays,
}: MusicPlayerProps) {
  const [currentSongIndex, setCurrentSongIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [completed, setCompleted] = useState(false)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const currentSong = songs[currentSongIndex]

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const recordPlay = useCallback(async () => {
    if (!currentSong || loading) return

    setLoading(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.from('song_plays').insert({
        user_id: userId,
        song_id: currentSong.id,
        investment_id: investmentId,
        earned_amount: earningPerSong,
      })

      if (error) throw error

      setCompleted(true)
      
      // Wait a moment then move to next song or refresh
      setTimeout(() => {
        if (currentSongIndex < songs.length - 1 && currentSongIndex < remainingPlays - 1) {
          setCurrentSongIndex((prev) => prev + 1)
          setProgress(0)
          setCompleted(false)
          setIsPlaying(false)
        } else {
          router.refresh()
        }
      }, 1500)
    } catch (error) {
      console.error('Error recording play:', error)
    } finally {
      setLoading(false)
    }
  }, [currentSong, userId, investmentId, earningPerSong, loading, currentSongIndex, songs.length, remainingPlays, router])

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isPlaying && !completed) {
      interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + (100 / PLAY_DURATION)
          if (newProgress >= 100) {
            setIsPlaying(false)
            recordPlay()
            return 100
          }
          return newProgress
        })
      }, 1000)
    }

    return () => clearInterval(interval)
  }, [isPlaying, completed, recordPlay])

  const togglePlay = () => {
    if (completed) return
    setIsPlaying(!isPlaying)
  }

  const skipSong = () => {
    if (currentSongIndex < songs.length - 1) {
      setCurrentSongIndex((prev) => prev + 1)
      setProgress(0)
      setCompleted(false)
      setIsPlaying(false)
    }
  }

  if (!currentSong) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
            <Music className="w-8 h-8 text-muted-foreground" />
          </div>
          <CardTitle className="mb-2">No Songs Available</CardTitle>
          <p className="text-muted-foreground">Check back later for new songs</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Music className="w-5 h-5 text-primary" />
          Now Playing
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Song Info */}
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
            <Music className="w-10 h-10 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg truncate">{currentSong.title}</h3>
            <p className="text-muted-foreground truncate">{currentSong.artist || 'Unknown Artist'}</p>
            <p className="text-sm text-primary font-medium mt-1">
              Earn {formatCurrency(earningPerSong)}
            </p>
          </div>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{Math.floor((progress / 100) * PLAY_DURATION)}s</span>
            <span>{PLAY_DURATION}s</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={skipSong}
            disabled={currentSongIndex >= songs.length - 1 || isPlaying}
          >
            <SkipForward className="w-5 h-5" />
          </Button>

          <Button
            size="lg"
            className="w-16 h-16 rounded-full"
            onClick={togglePlay}
            disabled={completed || loading}
          >
            {loading ? (
              <Loader2 className="w-8 h-8 animate-spin" />
            ) : completed ? (
              <CheckCircle className="w-8 h-8" />
            ) : isPlaying ? (
              <Pause className="w-8 h-8" />
            ) : (
              <Play className="w-8 h-8 ml-1" />
            )}
          </Button>

          <div className="w-10" /> {/* Spacer for alignment */}
        </div>

        {/* Status */}
        <div className="text-center">
          {completed ? (
            <p className="text-green-600 font-medium">
              +{formatCurrency(earningPerSong)} earned!
            </p>
          ) : isPlaying ? (
            <p className="text-muted-foreground">Keep listening to earn...</p>
          ) : (
            <p className="text-muted-foreground">Press play to start earning</p>
          )}
        </div>

        {/* Song Queue */}
        <div className="border-t pt-4">
          <p className="text-sm text-muted-foreground mb-2">
            Up next ({Math.min(remainingPlays - 1, songs.length - currentSongIndex - 1)} more)
          </p>
          <div className="space-y-2">
            {songs.slice(currentSongIndex + 1, currentSongIndex + 4).map((song) => (
              <div key={song.id} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
                  <Music className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{song.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{song.artist || 'Unknown Artist'}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
