'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { InvestmentPlan } from '@/lib/types/database'
import { createClient } from '@/lib/supabase/client'
import { Music, Sparkles, Check, Loader2, Copy, CreditCard, AlertCircle } from 'lucide-react'

interface InvestmentPlansProps {
  plans: InvestmentPlan[]
  userId: string
  hasActiveInvestment: boolean
}

const PAYMENT_ACCOUNT = {
  bankName: 'Smartcash PSB',
  accountNumber: '8086240621',
  accountName: 'Diwali Express',
}

// Generate unique payment code
function generatePaymentCode(planName: string) {
  const prefix = planName.substring(0, 3).toUpperCase()
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = Math.random().toString(36).substring(2, 6).toUpperCase()
  return `DW-${prefix}-${timestamp}-${random}`
}

export function InvestmentPlans({ plans, userId, hasActiveInvestment }: InvestmentPlansProps) {
  const [selectedPlan, setSelectedPlan] = useState<InvestmentPlan | null>(null)
  const [paymentCode, setPaymentCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [codeCopied, setCodeCopied] = useState(false)
  const [step, setStep] = useState<'select' | 'payment' | 'confirm'>('select')
  const router = useRouter()

  // Generate new payment code when plan is selected
  useEffect(() => {
    if (selectedPlan) {
      setPaymentCode(generatePaymentCode(selectedPlan.name))
      setStep('payment')
    }
  }, [selectedPlan])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const copyAccountNumber = () => {
    navigator.clipboard.writeText(PAYMENT_ACCOUNT.accountNumber)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const copyPaymentCode = () => {
    navigator.clipboard.writeText(paymentCode)
    setCodeCopied(true)
    setTimeout(() => setCodeCopied(false), 2000)
  }

  const handleSubmitPayment = async () => {
    if (!selectedPlan || !paymentCode) return

    setLoading(true)
    const supabase = createClient()

    try {
      // Create investment with unique payment code
      const { error } = await supabase.from('user_investments').insert({
        user_id: userId,
        plan_id: selectedPlan.id,
        amount: selectedPlan.amount,
        payment_reference: paymentCode,
        status: 'pending',
      })

      if (error) throw error

      // Create notification for user
      await supabase.from('notifications').insert({
        user_id: userId,
        title: 'Investment Submitted',
        message: `Your ${selectedPlan.name} investment of ${formatCurrency(selectedPlan.amount)} with code ${paymentCode} is pending admin approval.`,
        type: 'info',
      })

      setStep('confirm')
    } catch (error) {
      console.error('Error creating investment:', error)
    } finally {
      setLoading(false)
    }
  }

  const closeDialog = () => {
    setSelectedPlan(null)
    setPaymentCode('')
    setStep('select')
    router.refresh()
  }

  return (
    <>
      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan, index) => (
          <Card
            key={plan.id}
            className={`relative ${index === 1 ? 'border-primary shadow-lg' : ''}`}
          >
            {index === 1 && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full">
                Popular
              </div>
            )}
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="w-5 h-5 text-primary" />
                {plan.name}
              </CardTitle>
              <div className="text-3xl font-bold">{formatCurrency(plan.amount)}</div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-primary" />
                  </div>
                  <span>{plan.daily_songs} songs per day</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-primary" />
                  </div>
                  <span>{formatCurrency(plan.earning_per_song)} per song</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-primary" />
                  </div>
                  <span>{formatCurrency(plan.daily_songs * plan.earning_per_song)} daily earnings</span>
                </div>
              </div>

              <Button
                className="w-full"
                variant={index === 1 ? 'default' : 'outline'}
                onClick={() => setSelectedPlan(plan)}
                disabled={hasActiveInvestment}
              >
                {hasActiveInvestment ? 'Already Invested' : 'Select Plan'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Payment Dialog */}
      <Dialog open={!!selectedPlan} onOpenChange={closeDialog}>
        <DialogContent className="sm:max-w-md">
          {step === 'payment' && (
            <>
              <DialogHeader>
                <DialogTitle>Complete Payment</DialogTitle>
                <DialogDescription>
                  Transfer {selectedPlan && formatCurrency(selectedPlan.amount)} to the account below
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {/* Unique Payment Code - IMPORTANT */}
                <Alert className="border-primary bg-primary/5">
                  <AlertCircle className="h-4 w-4 text-primary" />
                  <AlertDescription className="text-sm">
                    <strong>IMPORTANT:</strong> Use this code as your payment remark/narration
                  </AlertDescription>
                </Alert>

                <div className="bg-primary/10 border-2 border-primary border-dashed rounded-lg p-4 text-center">
                  <p className="text-xs text-muted-foreground mb-1">Your Unique Payment Code</p>
                  <div className="flex items-center justify-center gap-2">
                    <span className="font-mono font-bold text-lg text-primary">{paymentCode}</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={copyPaymentCode}>
                      {codeCopied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Write this code in the remark/narration field during transfer
                  </p>
                </div>

                {/* Payment Details */}
                <div className="bg-muted rounded-lg p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Bank</span>
                    <span className="font-medium">{PAYMENT_ACCOUNT.bankName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Account Number</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-medium">{PAYMENT_ACCOUNT.accountNumber}</span>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={copyAccountNumber}>
                        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Account Name</span>
                    <span className="font-medium">{PAYMENT_ACCOUNT.accountName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Amount</span>
                    <span className="font-bold text-primary">
                      {selectedPlan && formatCurrency(selectedPlan.amount)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Plan</span>
                    <span className="font-medium">{selectedPlan?.name}</span>
                  </div>
                </div>

                <Button
                  className="w-full"
                  onClick={handleSubmitPayment}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4 mr-2" />
                      I Have Made Payment
                    </>
                  )}
                </Button>

                <p className="text-xs text-center text-muted-foreground">
                  Your subscription will be activated after admin verification
                </p>
              </div>
            </>
          )}

          {step === 'confirm' && (
            <>
              <DialogHeader>
                <DialogTitle className="text-center">Payment Submitted</DialogTitle>
              </DialogHeader>

              <div className="space-y-4 text-center">
                <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center">
                  <Check className="w-8 h-8 text-green-600" />
                </div>
                
                <div>
                  <p className="font-medium">Your payment is pending approval</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Admin will verify your payment with code:
                  </p>
                  <p className="font-mono font-bold text-primary mt-2">{paymentCode}</p>
                </div>

                <div className="bg-muted rounded-lg p-3 text-sm">
                  <p><strong>Plan:</strong> {selectedPlan?.name}</p>
                  <p><strong>Amount:</strong> {selectedPlan && formatCurrency(selectedPlan.amount)}</p>
                </div>

                <p className="text-xs text-muted-foreground">
                  You will receive a notification once your subscription is activated
                </p>

                <Button onClick={closeDialog} className="w-full">
                  Done
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
