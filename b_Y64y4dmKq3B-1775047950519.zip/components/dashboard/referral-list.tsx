import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { User } from 'lucide-react'

interface Referral {
  id: string
  full_name: string | null
  email: string
  created_at: string
}

interface ReferralListProps {
  referrals: Referral[]
}

export function ReferralList({ referrals }: ReferralListProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  if (referrals.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Your Referrals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <User className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <p className="font-medium">No referrals yet</p>
            <p className="text-sm">Share your referral code to start earning</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Your Referrals ({referrals.length})</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {referrals.map((referral) => (
            <div
              key={referral.id}
              className="flex items-center justify-between py-3 border-b last:border-0"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{referral.full_name || 'Anonymous'}</p>
                  <p className="text-xs text-muted-foreground">{referral.email}</p>
                </div>
              </div>
              <span className="text-xs text-muted-foreground">
                {formatDate(referral.created_at)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
