'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Gift, Loader2, Check } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

interface DailyBonusCardProps {
  userId: string
  hasClaimed: boolean
  hasActiveInvestment: boolean
}

const DAILY_BONUS_AMOUNT = 50

export function DailyBonusCard({ userId, hasClaimed, hasActiveInvestment }: DailyBonusCardProps) {
  const [loading, setLoading] = useState(false)
  const [claimed, setClaimed] = useState(hasClaimed)
  const router = useRouter()

  const claimBonus = async () => {
    if (claimed || loading || !hasActiveInvestment) return

    setLoading(true)
    const supabase = createClient()

    try {
      // Insert daily bonus
      const { error: bonusError } = await supabase
        .from('daily_bonuses')
        .insert({
          user_id: userId,
          amount: DAILY_BONUS_AMOUNT,
        })

      if (bonusError) throw bonusError

      // Update wallet
      const { error: walletError } = await supabase.rpc('add_to_wallet', {
        p_user_id: userId,
        p_amount: DAILY_BONUS_AMOUNT,
      })

      // If RPC doesn't exist, update directly
      if (walletError) {
        await supabase
          .from('wallets')
          .update({
            balance: supabase.rpc('increment', { x: DAILY_BONUS_AMOUNT }),
            total_earnings: supabase.rpc('increment', { x: DAILY_BONUS_AMOUNT }),
          })
          .eq('user_id', userId)
      }

      // Create transaction
      await supabase.from('transactions').insert({
        user_id: userId,
        type: 'bonus',
        amount: DAILY_BONUS_AMOUNT,
        description: 'Daily login bonus',
      })

      setClaimed(true)
      router.refresh()
    } catch (error) {
      console.error('Error claiming bonus:', error)
    } finally {
      setLoading(false)
    }
  }

  if (!hasActiveInvestment) {
    return null
  }

  return (
    <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Gift className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="font-semibold">Daily Login Bonus</p>
              <p className="text-sm text-muted-foreground">
                {claimed ? 'Claimed today!' : 'Claim your N50 bonus'}
              </p>
            </div>
          </div>
          <Button
            onClick={claimBonus}
            disabled={claimed || loading}
            variant={claimed ? 'outline' : 'default'}
            size="sm"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : claimed ? (
              <>
                <Check className="w-4 h-4 mr-1" />
                Claimed
              </>
            ) : (
              'Claim N50'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
