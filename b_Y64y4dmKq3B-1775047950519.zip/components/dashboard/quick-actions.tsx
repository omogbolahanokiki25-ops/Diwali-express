import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Music, CreditCard, ArrowDownToLine, Share2 } from 'lucide-react'

interface QuickActionsProps {
  hasActiveInvestment: boolean
}

export function QuickActions({ hasActiveInvestment }: QuickActionsProps) {
  const actions = [
    {
      href: hasActiveInvestment ? '/dashboard/earn' : '/dashboard/invest',
      icon: hasActiveInvestment ? Music : CreditCard,
      label: hasActiveInvestment ? 'Start Earning' : 'Invest Now',
      description: hasActiveInvestment ? 'Listen to songs' : 'Choose a plan',
      color: 'bg-primary/10 text-primary',
    },
    {
      href: '/dashboard/invest',
      icon: CreditCard,
      label: 'Upgrade',
      description: 'Get more songs',
      color: 'bg-blue-500/10 text-blue-500',
    },
    {
      href: '/dashboard/wallet',
      icon: ArrowDownToLine,
      label: 'Withdraw',
      description: 'Cash out earnings',
      color: 'bg-green-500/10 text-green-500',
    },
    {
      href: '/dashboard/referrals',
      icon: Share2,
      label: 'Invite',
      description: 'Share & earn',
      color: 'bg-purple-500/10 text-purple-500',
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {actions.map((action) => (
        <Link key={action.href + action.label} href={action.href}>
          <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
            <CardContent className="p-4 flex flex-col items-center text-center gap-2">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${action.color}`}>
                <action.icon className="w-6 h-6" />
              </div>
              <div>
                <p className="font-semibold text-sm">{action.label}</p>
                <p className="text-xs text-muted-foreground">{action.description}</p>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
