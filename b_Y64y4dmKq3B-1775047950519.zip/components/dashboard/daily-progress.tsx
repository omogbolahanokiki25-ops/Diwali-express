import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Music, ArrowRight } from 'lucide-react'

interface DailyProgressProps {
  currentPlays: number
  maxPlays: number
  earningPerSong: number
}

export function DailyProgress({ currentPlays, maxPlays, earningPerSong }: DailyProgressProps) {
  const progress = maxPlays > 0 ? (currentPlays / maxPlays) * 100 : 0
  const remainingPlays = maxPlays - currentPlays
  const potentialEarnings = remainingPlays * earningPerSong
  const earnedToday = currentPlays * earningPerSong

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Music className="w-5 h-5 text-primary" />
          {"Today's Progress"}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-muted-foreground">Songs completed</span>
            <span className="font-medium">{currentPlays} / {maxPlays}</span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="bg-muted/50 rounded-lg p-3">
            <p className="text-xs text-muted-foreground">Earned Today</p>
            <p className="text-lg font-bold text-green-600">{formatCurrency(earnedToday)}</p>
          </div>
          <div className="bg-muted/50 rounded-lg p-3">
            <p className="text-xs text-muted-foreground">Remaining</p>
            <p className="text-lg font-bold">{formatCurrency(potentialEarnings)}</p>
          </div>
        </div>

        {remainingPlays > 0 ? (
          <Button asChild className="w-full">
            <Link href="/dashboard/earn">
              Continue Earning
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
        ) : (
          <div className="text-center p-3 bg-green-500/10 rounded-lg">
            <p className="text-green-600 font-medium">All tasks completed for today!</p>
            <p className="text-xs text-muted-foreground">Come back tomorrow for more earnings</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
