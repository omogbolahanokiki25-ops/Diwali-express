export interface Profile {
  id: string
  email: string
  phone: string | null
  full_name: string | null
  referral_code: string
  referred_by: string | null
  referral_count: number
  is_admin: boolean
  is_blocked: boolean
  created_at: string
  updated_at: string
}

export interface InvestmentPlan {
  id: string
  name: string
  amount: number
  daily_songs: number
  earning_per_song: number
  description: string | null
  is_active: boolean
  created_at: string
}

export interface UserInvestment {
  id: string
  user_id: string
  plan_id: string
  amount: number
  status: 'pending' | 'active' | 'expired' | 'cancelled'
  payment_reference: string | null
  activated_at: string | null
  expires_at: string | null
  created_at: string
  plan?: InvestmentPlan
}

export interface Song {
  id: string
  title: string
  artist: string | null
  duration_seconds: number
  audio_url: string | null
  thumbnail_url: string | null
  is_active: boolean
  created_at: string
}

export interface SongPlay {
  id: string
  user_id: string
  song_id: string
  investment_id: string
  earned_amount: number
  played_at: string
  play_date: string
  song?: Song
}

export interface Wallet {
  id: string
  user_id: string
  balance: number
  total_earnings: number
  total_invested: number
  total_withdrawn: number
  created_at: string
  updated_at: string
}

export interface Withdrawal {
  id: string
  user_id: string
  amount: number
  bank_name: string
  account_number: string
  status: 'pending' | 'approved' | 'rejected' | 'processing' | 'completed'
  admin_note: string | null
  processed_by: string | null
  processed_at: string | null
  created_at: string
  user?: Profile
}

export interface Transaction {
  id: string
  user_id: string
  type: 'investment' | 'earning' | 'withdrawal' | 'bonus' | 'referral_bonus'
  amount: number
  description: string | null
  reference_id: string | null
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  title: string
  message: string
  type: 'info' | 'success' | 'warning' | 'error'
  is_read: boolean
  created_at: string
}

export interface DailyBonus {
  id: string
  user_id: string
  amount: number
  bonus_date: string
  created_at: string
}

// Dashboard stats
export interface DashboardStats {
  wallet: Wallet | null
  activeInvestment: UserInvestment | null
  todayPlays: number
  maxDailyPlays: number
  referralCount: number
  notifications: Notification[]
}

// Leaderboard entry
export interface LeaderboardEntry {
  id: string
  full_name: string | null
  referral_count: number
  total_earnings: number
  rank: number
}
