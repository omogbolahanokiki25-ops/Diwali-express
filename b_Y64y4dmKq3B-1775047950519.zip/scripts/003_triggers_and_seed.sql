-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS TEXT AS $$
DECLARE
  code TEXT;
  exists_check BOOLEAN;
BEGIN
  LOOP
    code := 'DW' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT) FROM 1 FOR 6));
    SELECT EXISTS(SELECT 1 FROM public.profiles WHERE referral_code = code) INTO exists_check;
    IF NOT exists_check THEN
      RETURN code;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Trigger function to auto-create profile and wallet on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_id UUID;
  ref_code TEXT;
BEGIN
  -- Generate unique referral code
  ref_code := generate_referral_code();
  
  -- Check for referral code in metadata
  IF NEW.raw_user_meta_data->>'referred_by' IS NOT NULL THEN
    SELECT id INTO referrer_id FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referred_by';
  END IF;

  -- Create profile
  INSERT INTO public.profiles (id, email, phone, full_name, referral_code, referred_by, is_admin)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'phone', NULL),
    COALESCE(NEW.raw_user_meta_data->>'full_name', NULL),
    ref_code,
    referrer_id,
    COALESCE((NEW.raw_user_meta_data->>'is_admin')::BOOLEAN, FALSE)
  )
  ON CONFLICT (id) DO NOTHING;

  -- Create wallet for the user
  INSERT INTO public.wallets (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;

  -- Update referrer's count if applicable
  IF referrer_id IS NOT NULL THEN
    UPDATE public.profiles 
    SET referral_count = referral_count + 1
    WHERE id = referrer_id;
    
    -- Add notification for referrer
    INSERT INTO public.notifications (user_id, title, message, type)
    VALUES (referrer_id, 'New Referral!', 'Someone just signed up using your referral code!', 'success');
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Function to update wallet on earnings
CREATE OR REPLACE FUNCTION update_wallet_on_earning()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.wallets
  SET 
    balance = balance + NEW.earned_amount,
    total_earnings = total_earnings + NEW.earned_amount,
    updated_at = NOW()
  WHERE user_id = NEW.user_id;
  
  -- Record transaction
  INSERT INTO public.transactions (user_id, type, amount, description, reference_id)
  VALUES (NEW.user_id, 'earning', NEW.earned_amount, 'Song listening reward', NEW.id);
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_song_play ON public.song_plays;
CREATE TRIGGER on_song_play
  AFTER INSERT ON public.song_plays
  FOR EACH ROW
  EXECUTE FUNCTION update_wallet_on_earning();

-- Seed investment plans
INSERT INTO public.investment_plans (name, amount, daily_songs, earning_per_song, description) VALUES
  ('Basic Plan', 5000.00, 5, 200.00, 'Perfect for beginners. Listen to 5 songs daily and earn ₦1,000 per day.'),
  ('Premium Plan', 10000.00, 10, 250.00, 'More songs, more earnings! Listen to 10 songs daily and earn ₦2,500 per day.'),
  ('VIP Plan', 15000.00, 20, 300.00, 'Maximum earnings! Listen to 20 songs daily and earn ₦6,000 per day.')
ON CONFLICT DO NOTHING;

-- Seed sample songs
INSERT INTO public.songs (title, artist, duration_seconds) VALUES
  ('Festival Beats', 'DJ Diwali', 30),
  ('Naija Vibes', 'Afrobeats Master', 30),
  ('Golden Dreams', 'The Earners', 30),
  ('Money Flow', 'Cash Kings', 30),
  ('Celebration Time', 'Party Crew', 30),
  ('Success Story', 'Motivational Beats', 30),
  ('Wealth Anthem', 'Rich Sounds', 30),
  ('Happy Days', 'Good Vibes Only', 30),
  ('Rising Star', 'Future Legends', 30),
  ('Victory Dance', 'Champions United', 30),
  ('Bright Future', 'Hope Collective', 30),
  ('Express Yourself', 'Freedom Sounds', 30),
  ('Diwali Night', 'Festival Ensemble', 30),
  ('Earn More', 'Hustle Squad', 30),
  ('Blessed Life', 'Gratitude Gang', 30),
  ('Light It Up', 'Fireworks Band', 30),
  ('Prosperity', 'Abundance Crew', 30),
  ('Joy Unlimited', 'Happiness Project', 30),
  ('New Beginnings', 'Fresh Start', 30),
  ('Shine Bright', 'Diamond Stars', 30)
ON CONFLICT DO NOTHING;
